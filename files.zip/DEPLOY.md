# Deploy Guide

End-to-end deployment to Cloudflare Pages with Cloudflare Access (auth) and KV (shared scenario storage).

**Time required:** ~15 minutes if you already have a Cloudflare account and your domain pointed there. Add ~10 minutes if you don't.

**Cost:** $0 at this scale. Free tiers cover everything (Pages, KV, Access for ≤50 users).

---

## Step 1 — Push to GitHub

```bash
cd finlete-projections
git init
git add .
git commit -m "Initial commit — Finlete projections model"
gh repo create finlete-projections --private --source=. --remote=origin --push
```

(Or use the GitHub UI — make it **private**.)

---

## Step 2 — Connect Cloudflare Pages

1. Cloudflare dashboard → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**
2. Authorize the GitHub integration (one-time) and pick `finlete-projections`
3. Build settings:
   - **Framework preset:** Vite
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
   - **Root directory:** `/` (default)
4. Click **Save and Deploy**

First build takes ~90 seconds. You'll get a URL like `finlete-projections.pages.dev`. Visit it — the model loads but `/api/presets` will return 500 until the next step.

---

## Step 3 — Create the KV namespace

1. Cloudflare dashboard → **Storage & Databases** → **KV** → **Create namespace**
2. Name it `finlete-presets` (or anything — the binding name in the next step is what matters)
3. Click **Add**

---

## Step 4 — Bind KV to the Pages project

1. Go back to your Pages project (`finlete-projections`)
2. **Settings** → **Bindings** → **Add binding**
3. Type: **KV namespace**
4. Variable name: `PRESETS` (this exact name — the function code reads `env.PRESETS`)
5. KV namespace: select the `finlete-presets` namespace from Step 3
6. **Save**

⚠️ Bindings only apply to **future deployments**. Trigger a redeploy: in the Pages **Deployments** tab, find the latest deployment, click **... → Retry deployment**. Or push a trivial commit.

After redeploy, visit `https://your-site.pages.dev/api/presets` directly — you should see `{"data":null,"lastSavedBy":null,"lastSavedAt":null}`. If you get an error, the binding isn't applied — re-check Step 4 and redeploy.

---

## Step 5 — Add Cloudflare Access (authentication)

1. Cloudflare dashboard → **Zero Trust** (left sidebar — may need one-time setup, free)
2. **Access** → **Applications** → **Add an application** → **Self-hosted**
3. Application configuration:
   - **Application name:** Finlete Projections
   - **Session duration:** 24 hours (or whatever — 1 month also fine for trusted users)
   - **Application domain:** your Pages URL (e.g., `finlete-projections.pages.dev`) or a custom domain if you've set one up
4. Click **Next**
5. Add a policy:
   - **Policy name:** Allowed users
   - **Action:** Allow
   - **Configure rules** → Selector: **Emails**, Value: `rob@finlete.com, max@finlete.com` (or whatever the actual addresses are)
6. **Next** through the rest, click **Add application**

Visit your Pages URL in an incognito window. You should see a Cloudflare Access login screen asking for your email. Enter Rob's address → check inbox for a one-time PIN → enter PIN → you're in. Same flow for Max with his email.

⚠️ **Test in incognito.** If you're already authenticated to Cloudflare, you'll get straight in and won't see the login screen.

---

## Step 6 — Verify the shared save flow

In your authenticated browser:

1. Click **Growth** preset
2. Move any slider (e.g., Marketing spend → $75K)
3. Click **Save to Growth** — should see ✓ SAVED briefly
4. Note the "Last saved by rob" attribution row

In another browser (or have Max try):

1. Visit the same URL, authenticate
2. The page should load with your $75K value applied to Growth
3. Attribution shows "Last saved by rob"

If both of those work, you're done.

---

## Custom domain (optional)

1. Pages project → **Custom domains** → **Set up a custom domain**
2. Enter e.g. `model.finlete.com` — Cloudflare auto-creates the CNAME if the domain is on Cloudflare DNS
3. Update the **Cloudflare Access application domain** (Step 5.3) to match the new custom domain
4. Done

---

## Troubleshooting

**`/api/presets` returns 500 with "KV binding PRESETS missing"**
→ Step 4 wasn't completed, or the redeploy didn't happen after binding. Push a commit or retry the deployment.

**Save button shows ✗ SAVE FAILED**
→ Open browser devtools → Network tab → click Save again → look at the `/api/presets` POST response. If it's 401, Access is blocking the API request (rare — usually means the session expired; reload the page). If it's 500, check Cloudflare Pages function logs.

**Can't log in via Access**
→ Email typo in the policy. Edit the policy in Zero Trust → Access → Applications → Edit → Policies.

**Concurrent saves overwrite each other**
→ Yes, this is by design (last-write-wins). For 2 users this is fine. If it becomes an issue, the simplest fix is to add a "Refresh" prompt before save when `lastSavedAt` has changed since you loaded — but I'd wait until that actually causes a problem.

---

## Updating the model

Push to `main` → Pages auto-deploys. Saved presets in KV survive across deploys (they're separate from the code).

To wipe shared presets and reset everyone to defaults: Cloudflare dashboard → KV → `finlete-presets` namespace → delete the `shared` key. Next page load will use DEFAULT_PRESETS.
