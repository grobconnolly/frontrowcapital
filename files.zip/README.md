# Finlete · Projections

Internal unit-economics projection model for Finlete. Anchored to actual operating data (Jan 1 – Apr 30, 2026 funnel + lifetime aggregates from DealMaker / Airtable extracts). Used for LP scenario modeling and capital-need conversations.

**Internal use only.** Contains real Finlete operating data: spend, CPL, CAC, athlete-level performance, lifetime totals.

---

## What's inside

- **Single-page React app** (Vite + recharts). All UI in `src/App.jsx`.
- **Shared scenario state** between Rob and Max via Cloudflare KV. The `/api/presets` endpoint (Cloudflare Pages Function) reads/writes a single shared JSON blob attributed to whoever last saved.
- **Authentication** via Cloudflare Access (separate setup — see `DEPLOY.md`). The Pages Function uses the `Cf-Access-Authenticated-User-Email` header that Access injects to attribute saves.

## Local development

```bash
npm install
npm run dev
```

Local dev does **not** run the Pages Function — `/api/presets` will 404 in `vite dev`. The app handles this gracefully and falls back to the in-code DEFAULT_PRESETS. To test the API locally, build first then use Wrangler:

```bash
npm run build
npx wrangler pages dev dist
```

Wrangler will simulate the Pages environment including the KV binding (you'll need to configure a local binding or use `--kv PRESETS`).

## Deploy

See `DEPLOY.md` for the full Cloudflare Pages + KV + Access setup. Roughly:

1. Push this repo to a private GitHub repo
2. Cloudflare → Pages → connect repo (auto-deploys on push to `main`)
3. Create a KV namespace, bind it as `PRESETS` in the Pages project
4. Add a Cloudflare Access policy gating the entire site to specific emails

## File layout

```
finlete-projections/
├── functions/
│   └── api/
│       └── presets.js       Cloudflare Pages Function (GET/POST shared presets)
├── src/
│   ├── App.jsx              The model — all UI, sliders, projection math
│   ├── main.jsx             React entry point
│   └── index.css            Base reset + font wiring
├── public/                  Static assets (currently empty)
├── index.html               Mulish font preload + root mount
├── vite.config.js
├── package.json
└── .gitignore
```

## Data sources

The `HISTORICAL` constant in `App.jsx` is the source of truth for displayed baseline metrics. It encodes:

- Lifetime aggregates from DealMaker investor extract + Airtable lead extract
- Recent run-rate from Jan 1 – Apr 30, 2026 cohort (308 leads, 148 investors, $187K sales, $41,954 ad spend)

When updating with newer data, edit the `HISTORICAL` object directly and commit. There is no automated data sync.

## License

Proprietary — Finlete Inc. internal.
